app.filter('retornaoi', function(){
    return function(nome){
        
        return "Olá "+nome+"!";
        
    }
});